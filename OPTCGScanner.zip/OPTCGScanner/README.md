# OPTCG Scanner — Android App

A fast, no-confirm One Piece TCG card scanner for Android.  
Scan cards continuously, review & fix matches at the end, export to CSV.

---

## How it works

1. **First launch:** App downloads all One Piece card data from the free
   [TCGTracking API](https://tcgtracking.com/tcgapi/) and stores it locally in Room.
   This is a one-time sync (~100 sets, but One Piece has ~15 sets as of 2025).

2. **Scanning:** Point camera at the card number in the bottom-left corner
   (e.g. `OP03-001`). ML Kit OCR reads it on-device. 3 consecutive matching frames
   confirm the card — instant haptic pulse, brief overlay flash, move to next card.
   No button presses needed.

3. **Review:** All scanned cards shown in a list. Tap the swap icon to search and
   correct any misread. Adjust quantities with +/− steppers. Delete any errors.

4. **Export:** Share button → CSV file → share sheet.

---

## Architecture

```
app/src/main/java/com/optcgscanner/
├── data/
│   ├── db/           — Room DAOs + Database
│   ├── model/        — Entities (CardCache, ScanSession, ScannedCard, SetCatalogue)
│   └── repository/   — CardRepository, SessionRepository
├── network/          — Retrofit API service + response models
├── util/
│   └── CardNumberAnalyzer.kt   — CameraX ImageAnalysis.Analyzer (the scan brain)
├── ui/
│   ├── scanner/      — ScannerScreen + ScannerViewModel
│   ├── review/       — ReviewScreen + ReviewViewModel
│   ├── sessions/     — SessionsScreen + SessionsViewModel
│   ├── theme/        — Material3 theme (navy/gold)
│   └── OPTCGNavHost.kt
├── di/               — Hilt AppModule
├── MainActivity.kt
└── OPTCGApp.kt
```

---

## Key design decisions

### OCR-only (no image ML)
One Piece cards have a clearly printed card number (`OP03-001` format) that
ML Kit Text Recognition reads reliably even in mediocre lighting. This approach
is simpler, faster, and more accurate than image-fingerprinting for this use case.

### Debounce pattern
`CardNumberAnalyzer` requires 3 consecutive frames with the same card number
before emitting a confirmed match, then applies a 1.5-second lockout before
accepting another scan of the same number. This prevents double-scans while
moving cards without needing manual confirmation.

### Local-first database
All card data is cached in Room on first launch. Scan lookups are pure local DB
queries — no network call per scan. Re-sync every 7 days matches the API's own
cache TTL for product data.

### Card number regex
```kotlin
val regex = Regex("""(OP\d{2}|ST\d{2}|EB\d{2}|P)-\d{3}""")
```
Covers all current One Piece set codes. Add new prefixes here if future sets
use different codes.

---

## Setup & Build

### Requirements
- Android Studio Ladybug (2024.2+)
- JDK 17
- Min SDK 26 (Android 8.0)

### Build
```bash
git clone <repo>
cd OPTCGScanner
./gradlew assembleDebug
```

Install to device:
```bash
./gradlew installDebug
```

---

## Tuning scan sensitivity

Edit `CardNumberAnalyzer.kt`:

| Constant | Default | Effect |
|---|---|---|
| `CONFIRM_FRAMES` | 3 | Higher = fewer false positives, slightly slower |
| `LOCKOUT_MS` | 1500 | Increase if same card triggers twice |
| `SAMPLE_EVERY_N_FRAMES` | 4 | Lower = faster but more CPU/battery |

---

## CSV export format

```
Card Number,Name,Set,Quantity,Manually Edited
OP03-001,"Monkey D. Luffy",Pillars of Strength,2,false
OP03-016,"Sanji",Pillars of Strength,1,true
```

---

## Extending

- **Add pricing:** Call `/tcgapi/v1/{cat}/sets/{set}/pricing` and join to `CardCache` by `productId`
- **Japanese cards:** Add JP set code patterns to the regex; separate the category fetch to also pull JP sets
- **Barcode fallback:** Some sealed products have barcodes — add a ZXing analyzer alongside OCR
