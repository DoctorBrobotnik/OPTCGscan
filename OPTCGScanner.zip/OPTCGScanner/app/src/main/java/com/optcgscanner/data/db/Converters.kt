package com.optcgscanner.data.db

import androidx.room.TypeConverter
import com.optcgscanner.data.model.AlternateType

class Converters {
    @TypeConverter
    fun fromAlternateType(value: AlternateType): String = value.name

    @TypeConverter
    fun toAlternateType(value: String): AlternateType =
        AlternateType.entries.firstOrNull { it.name == value } ?: AlternateType.BASE
}
