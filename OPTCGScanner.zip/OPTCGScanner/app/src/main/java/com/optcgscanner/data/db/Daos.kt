package com.optcgscanner.data.db

import androidx.room.*
import com.optcgscanner.data.model.*
import kotlinx.coroutines.flow.Flow

// ─── Card Cache ─────────────────────────────────────────────────────────────

@Dao
interface CardCacheDao {

    /** All versions (base + alternates) that share a card number — for the variant picker */
    @Query("SELECT * FROM card_cache WHERE cardNumber = :cardNumber ORDER BY alternateType ASC")
    suspend fun findAllByCardNumber(cardNumber: String): List<CardCache>

    /** The base/standard version of a card — used as the default scan match */
    @Query("""
        SELECT * FROM card_cache 
        WHERE cardNumber = :cardNumber AND alternateType = 'BASE' 
        LIMIT 1
    """)
    suspend fun findBaseByCardNumber(cardNumber: String): CardCache?

    /** Fallback: any version when there's no base (e.g. promo-only cards) */
    @Query("SELECT * FROM card_cache WHERE cardNumber = :cardNumber LIMIT 1")
    suspend fun findAnyByCardNumber(cardNumber: String): CardCache?

    /** Full-text search across base names, for the correction search sheet */
    @Query("""
        SELECT * FROM card_cache 
        WHERE baseName LIKE '%' || :query || '%' 
           OR cardNumber LIKE '%' || :query || '%'
        GROUP BY cardNumber           
        ORDER BY baseName ASC
        LIMIT 30
    """)
    suspend fun searchByName(query: String): List<CardCache>

    @Upsert
    suspend fun upsertAll(cards: List<CardCache>)

    @Query("DELETE FROM card_cache WHERE setCode = :setCode")
    suspend fun deleteBySet(setCode: String)

    @Query("SELECT COUNT(*) FROM card_cache")
    suspend fun totalCount(): Int

    @Query("SELECT COUNT(DISTINCT cardNumber) FROM card_cache")
    suspend fun uniqueCardNumberCount(): Int
}

// ─── Set Catalogue ──────────────────────────────────────────────────────────

@Dao
interface SetCatalogueDao {
    @Query("SELECT * FROM set_catalogue ORDER BY setName ASC")
    fun observeAll(): Flow<List<SetCatalogue>>

    @Query("SELECT * FROM set_catalogue ORDER BY setName ASC")
    suspend fun getAll(): List<SetCatalogue>

    @Upsert
    suspend fun upsertAll(sets: List<SetCatalogue>)

    @Query("UPDATE set_catalogue SET syncedAt = :timestamp WHERE setId = :setId")
    suspend fun markSynced(setId: Int, timestamp: Long)
}

// ─── Scan Sessions ──────────────────────────────────────────────────────────

@Dao
interface ScanSessionDao {
    @Query("SELECT * FROM scan_sessions ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ScanSession>>

    @Query("SELECT * FROM scan_sessions WHERE id = :id")
    suspend fun getById(id: Long): ScanSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: ScanSession): Long

    @Update
    suspend fun update(session: ScanSession)

    @Delete
    suspend fun delete(session: ScanSession)

    @Query("UPDATE scan_sessions SET totalCards = :count WHERE id = :id")
    suspend fun updateCardCount(id: Long, count: Int)

    @Query("UPDATE scan_sessions SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)
}

// ─── Scanned Cards ──────────────────────────────────────────────────────────

@Dao
interface ScannedCardDao {
    @Query("SELECT * FROM scanned_cards WHERE sessionId = :sessionId ORDER BY scannedAt ASC")
    fun observeBySession(sessionId: Long): Flow<List<ScannedCard>>

    /**
     * Find an existing entry for the exact product (card number + version).
     * Two different versions of the same card are tracked as separate rows.
     */
    @Query("""
        SELECT * FROM scanned_cards 
        WHERE sessionId = :sessionId AND productId = :productId 
        LIMIT 1
    """)
    suspend fun findInSession(sessionId: Long, productId: Int): ScannedCard?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(card: ScannedCard): Long

    @Update
    suspend fun update(card: ScannedCard)

    @Delete
    suspend fun delete(card: ScannedCard)

    @Query("UPDATE scanned_cards SET quantity = quantity + 1 WHERE id = :id")
    suspend fun incrementQuantity(id: Long)

    @Query("UPDATE scanned_cards SET quantity = :qty WHERE id = :id")
    suspend fun setQuantity(id: Long, qty: Int)

    @Query("SELECT SUM(quantity) FROM scanned_cards WHERE sessionId = :sessionId")
    suspend fun totalCardsInSession(sessionId: Long): Int
}
