package com.optcgscanner.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.optcgscanner.data.model.*

@Database(
    entities = [CardCache::class, ScanSession::class, ScannedCard::class, SetCatalogue::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class OPTCGDatabase : RoomDatabase() {
    abstract fun cardCacheDao(): CardCacheDao
    abstract fun setCatalogueDao(): SetCatalogueDao
    abstract fun scanSessionDao(): ScanSessionDao
    abstract fun scannedCardDao(): ScannedCardDao
}
