package com.optcgscanner.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// ─── Cached card catalogue (synced from TCGTracking API) ───────────────────
//
// One card number can have MULTIPLE entries — the base card plus alternates
// (Parallel, Alternate Art, Manga Art, Treasure Rare, Special Rare, etc.).
// productId (TCGPlayer's unique ID) is therefore the real primary key.
//
// TCGPlayer encodes variant info into the product name using parenthetical
// suffixes, e.g.:
//   "Shanks"                                     → base
//   "Shanks (Parallel)"                          → parallel foil
//   "Shanks (Parallel) (Alternate Art)"          → alt art
//   "Shanks (Parallel) (Manga) (Alternate Art)"  → manga art
//
// We parse these at sync time into a structured AlternateType enum so the
// review screen can show a clean label and the right badge colour.

@Entity(tableName = "card_cache", indices = [Index("cardNumber")])
data class CardCache(
    @PrimaryKey val productId: Int,       // TCGPlayer product ID — truly unique
    val cardNumber: String,               // e.g. "OP03-001" — shared by alternates
    val name: String,                     // Full TCGPlayer name incl. parentheticals
    val baseName: String,                 // Just the character name, no suffixes
    val alternateType: AlternateType,     // Parsed variant classification
    val setCode: String,                  // e.g. "OP03"
    val setName: String,
    val rarity: String,                   // C / U / R / SR / L / SEC / TR / SP / AA
    val imageUrl: String,
    val syncedAt: Long = System.currentTimeMillis()
)

/**
 * Parsed variant type for a One Piece card product.
 * Derived from parenthetical tags in the TCGPlayer product name.
 *
 * Display labels and badge colours are defined in the UI layer via
 * [AlternateType.label] and [AlternateType.badgeColorHex].
 */
enum class AlternateType {
    /** Standard print — no alternates */
    BASE,
    /** Parallel foil — same art, textured foil finish, ★ symbol */
    PARALLEL,
    /** Alternate Art — different artwork, rainbow holofoil, ★ symbol */
    ALTERNATE_ART,
    /** Manga Art — manga panel artwork, textured foil, ★ symbol. Rarest pull. */
    MANGA_ART,
    /** Treasure Rare — full art foil, introduced OP06+ */
    TREASURE_RARE,
    /** Special Rare (SP) — extreme alternate art, ~1-2 per case */
    SPECIAL_RARE,
    /** Promotional card */
    PROMO,
    /** Any other variant not matched by the parser */
    OTHER;

    val label: String get() = when (this) {
        BASE          -> "Standard"
        PARALLEL      -> "Parallel"
        ALTERNATE_ART -> "Alternate Art"
        MANGA_ART     -> "Manga Art"
        TREASURE_RARE -> "Treasure Rare"
        SPECIAL_RARE  -> "Special Rare"
        PROMO         -> "Promo"
        OTHER         -> "Other Variant"
    }

    /** Hex colour string for badge background in the UI */
    val badgeColorHex: String get() = when (this) {
        BASE          -> "#607D8B"  // Blue-grey
        PARALLEL      -> "#5C6BC0"  // Indigo
        ALTERNATE_ART -> "#E65100"  // Deep orange
        MANGA_ART     -> "#6A1B9A"  // Deep purple
        TREASURE_RARE -> "#F9A825"  // Amber
        SPECIAL_RARE  -> "#AD1457"  // Pink
        PROMO         -> "#00695C"  // Teal
        OTHER         -> "#455A64"  // Dark grey
    }

    companion object {
        /**
         * Parse a TCGPlayer product name into an AlternateType.
         * The name typically looks like: "Shanks (Parallel) (Manga) (Alternate Art)"
         * We check for keywords in a specific order (most specific first).
         */
        fun parse(productName: String): AlternateType {
            val n = productName.lowercase()
            return when {
                "manga" in n && "alternate art" in n -> MANGA_ART
                "manga" in n                         -> MANGA_ART
                "alternate art" in n                 -> ALTERNATE_ART
                "treasure rare" in n || " tr)" in n  -> TREASURE_RARE
                "special rare" in n || " sp)" in n   -> SPECIAL_RARE
                "promo" in n                         -> PROMO
                "parallel" in n                      -> PARALLEL
                else                                 -> BASE
            }
        }

        /**
         * Strip all parenthetical variant suffixes from a product name
         * to get just the character/card name.
         * e.g. "Shanks (Parallel) (Manga) (Alternate Art)" → "Shanks"
         */
        fun extractBaseName(productName: String): String =
            productName.replace(Regex("""\s*\([^)]*\)"""), "").trim()
    }
}

// ─── Scan sessions ──────────────────────────────────────────────────────────

@Entity(tableName = "scan_sessions")
data class ScanSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,                     // user-editable, default = date/time
    val createdAt: Long = System.currentTimeMillis(),
    val totalCards: Int = 0
)

// ─── Individual scanned card entries ────────────────────────────────────────

@Entity(
    tableName = "scanned_cards",
    foreignKeys = [
        ForeignKey(
            entity = ScanSession::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class ScannedCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val cardNumber: String,               // shared by all versions of the card
    val productId: Int,                   // TCGPlayer ID of the specific version logged
    val cardName: String,                 // baseName of the card (no variant suffixes)
    val alternateType: AlternateType,     // which version was recorded
    val setName: String,
    val imageUrl: String,
    val quantity: Int = 1,
    val manuallyEdited: Boolean = false,
    val scannedAt: Long = System.currentTimeMillis()
)

// ─── Set catalogue (one row per set, tracks sync state) ─────────────────────

@Entity(tableName = "set_catalogue")
data class SetCatalogue(
    @PrimaryKey val setId: Int,
    val setCode: String,
    val setName: String,
    val productCount: Int,
    val syncedAt: Long = 0L              // 0 = never synced
)
