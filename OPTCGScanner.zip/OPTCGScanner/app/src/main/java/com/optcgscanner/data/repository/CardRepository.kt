package com.optcgscanner.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.optcgscanner.data.db.CardCacheDao
import com.optcgscanner.data.db.SetCatalogueDao
import com.optcgscanner.data.model.AlternateType
import com.optcgscanner.data.model.CardCache
import com.optcgscanner.data.model.SetCatalogue
import com.optcgscanner.network.TcgTrackingApi
import com.optcgscanner.network.TcgTrackingConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "optcg_prefs")

private val KEY_ONE_PIECE_CAT_ID = intPreferencesKey("one_piece_cat_id")
private val KEY_LAST_SETS_SYNC = longPreferencesKey("last_sets_sync")

// Sync sets list every 7 days (matches API cache TTL)
private const val SETS_SYNC_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000L
// Re-sync a set's cards every 7 days
private const val SET_SYNC_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000L

@Singleton
class CardRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: TcgTrackingApi,
    private val cardCacheDao: CardCacheDao,
    private val setCatalogueDao: SetCatalogueDao
) {
    val allSets: Flow<List<SetCatalogue>> = setCatalogueDao.observeAll()

    // ─── Lookup (called during scanning, must be fast) ───────────────────────

    /** Returns the base/standard version for auto-scan matching */
    suspend fun lookupBaseByCardNumber(cardNumber: String): CardCache? =
        cardCacheDao.findBaseByCardNumber(cardNumber)
            ?: cardCacheDao.findAnyByCardNumber(cardNumber)

    /** Returns ALL versions of a card — base + every alternate */
    suspend fun lookupAllVersions(cardNumber: String): List<CardCache> =
        cardCacheDao.findAllByCardNumber(cardNumber)

    /** Search returns one entry per unique card number (deduplicated) */
    suspend fun searchByName(query: String): List<CardCache> =
        cardCacheDao.searchByName(query)

    suspend fun totalCachedCards(): Int = cardCacheDao.totalCount()

    // ─── Sync orchestration ──────────────────────────────────────────────────

    /**
     * Ensures we have a valid One Piece category ID and a fresh sets list.
     * Safe to call from app startup — no-ops if data is recent.
     */
    suspend fun ensureSetsListFresh(): Result<Unit> = runCatching {
        val catId = getOrFetchOnePieceCatId()
        val lastSync = context.dataStore.data.first()[KEY_LAST_SETS_SYNC] ?: 0L
        val now = System.currentTimeMillis()
        if (now - lastSync < SETS_SYNC_INTERVAL_MS) return@runCatching

        val setsResponse = api.getSets(catId)
        val entities = setsResponse.sets.map { s ->
            SetCatalogue(
                setId = s.id,
                setCode = s.abbreviation ?: s.name.take(4).uppercase(),
                setName = s.name,
                productCount = s.productCount ?: 0
            )
        }
        setCatalogueDao.upsertAll(entities)
        context.dataStore.edit { it[KEY_LAST_SETS_SYNC] = now }
    }

    /**
     * Downloads and caches all card products for a specific set.
     * Only re-fetches if data is stale (>7 days) or forced.
     */
    suspend fun syncSet(setId: Int, force: Boolean = false): Result<Int> = runCatching {
        val set = setCatalogueDao.getAll().find { it.setId == setId }
            ?: error("Set $setId not found in catalogue")

        val now = System.currentTimeMillis()
        if (!force && now - set.syncedAt < SET_SYNC_INTERVAL_MS) {
            return@runCatching 0 // Already fresh
        }

        val catId = getOrFetchOnePieceCatId()
        val productsResponse = api.getProducts(catId, setId)

        val cards = productsResponse.products.mapNotNull { p ->
            val num = p.number?.trim()
            val image = p.imageUrl?.trim()
            if (num.isNullOrBlank() || image.isNullOrBlank()) return@mapNotNull null

            val cardNumber = if (num.contains("-")) num
            else "${set.setCode}-$num"

            val baseName = AlternateType.extractBaseName(p.name)
            val alternateType = AlternateType.parse(p.name)

            CardCache(
                productId = p.id,
                cardNumber = cardNumber,
                name = p.name,
                baseName = baseName,
                alternateType = alternateType,
                setCode = set.setCode,
                setName = set.setName,
                rarity = p.rarity ?: "?",
                imageUrl = image
            )
        }

        cardCacheDao.upsertAll(cards)
        setCatalogueDao.markSynced(setId, now)
        cards.size
    }

    /**
     * Syncs ALL sets that have never been synced. Called on first launch.
     * Reports progress via callback so UI can show a progress bar.
     */
    suspend fun syncAllSets(
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<Unit> = runCatching {
        ensureSetsListFresh().getOrThrow()
        val sets = setCatalogueDao.getAll()
        val unsynced = sets.filter { it.syncedAt == 0L }
        unsynced.forEachIndexed { idx, set ->
            onProgress(idx + 1, unsynced.size)
            syncSet(set.setId).getOrElse { /* skip on error, retry later */ }
        }
    }

    // ─── Internal helpers ────────────────────────────────────────────────────

    private suspend fun getOrFetchOnePieceCatId(): Int {
        val stored = context.dataStore.data.first()[KEY_ONE_PIECE_CAT_ID]
        if (stored != null && stored != 0) return stored

        // Discover from API
        val cats = api.getCategories()
        val onePiece = cats.categories.firstOrNull {
            it.name.contains("one piece", ignoreCase = true) ||
                    it.name.contains("onepiece", ignoreCase = true)
        } ?: error("Could not find One Piece category in TCGTracking API")

        context.dataStore.edit { it[KEY_ONE_PIECE_CAT_ID] = onePiece.id }
        return onePiece.id
    }
}
