package com.optcgscanner.data.repository

import com.optcgscanner.data.db.ScannedCardDao
import com.optcgscanner.data.db.ScanSessionDao
import com.optcgscanner.data.model.CardCache
import com.optcgscanner.data.model.ScannedCard
import com.optcgscanner.data.model.ScanSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionRepository @Inject constructor(
    private val sessionDao: ScanSessionDao,
    private val cardDao: ScannedCardDao
) {
    val allSessions: Flow<List<ScanSession>> = sessionDao.observeAll()

    fun observeCardsForSession(sessionId: Long): Flow<List<ScannedCard>> =
        cardDao.observeBySession(sessionId)

    // ─── Session management ──────────────────────────────────────────────────

    suspend fun createSession(): Long {
        val name = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date())
        return sessionDao.insert(ScanSession(name = name))
    }

    suspend fun renameSession(sessionId: Long, name: String) =
        sessionDao.rename(sessionId, name)

    suspend fun deleteSession(session: ScanSession) =
        sessionDao.delete(session)

    // ─── Card recording ──────────────────────────────────────────────────────

    /**
     * Called for each confirmed scan, using a specific [CardCache] version.
     * If the same productId is already in the session, increments quantity.
     * Different versions of the same card number are tracked as separate rows.
     */
    suspend fun recordScan(sessionId: Long, card: CardCache): ScannedCard {
        val existing = cardDao.findInSession(sessionId, card.productId)
        return if (existing != null) {
            cardDao.incrementQuantity(existing.id)
            existing.copy(quantity = existing.quantity + 1)
        } else {
            val id = cardDao.insert(
                ScannedCard(
                    sessionId = sessionId,
                    cardNumber = card.cardNumber,
                    productId = card.productId,
                    cardName = card.baseName,
                    alternateType = card.alternateType,
                    setName = card.setName,
                    imageUrl = card.imageUrl
                )
            )
            ScannedCard(
                id = id,
                sessionId = sessionId,
                cardNumber = card.cardNumber,
                productId = card.productId,
                cardName = card.baseName,
                alternateType = card.alternateType,
                setName = card.setName,
                imageUrl = card.imageUrl
            )
        }.also { refreshSessionCount(sessionId) }
    }

    suspend fun updateCardQuantity(cardId: Long, quantity: Int) =
        cardDao.setQuantity(cardId, quantity.coerceAtLeast(1))

    /**
     * Replace a scanned card entry with a different [CardCache] version.
     * Used both for correcting wrong OCR matches AND for changing alternate version.
     */
    suspend fun replaceWithVersion(scanned: ScannedCard, replacement: CardCache) {
        cardDao.update(
            scanned.copy(
                cardNumber = replacement.cardNumber,
                productId = replacement.productId,
                cardName = replacement.baseName,
                alternateType = replacement.alternateType,
                setName = replacement.setName,
                imageUrl = replacement.imageUrl,
                manuallyEdited = true
            )
        )
    }

    suspend fun deleteCard(card: ScannedCard) {
        cardDao.delete(card)
        refreshSessionCount(card.sessionId)
    }

    // ─── CSV export ──────────────────────────────────────────────────────────

    suspend fun exportSessionToCsv(sessionId: Long): String {
        val cards = cardDao.observeBySession(sessionId).first()
        return buildCsv(cards)
    }

    fun buildCsv(cards: List<ScannedCard>): String {
        val sb = StringBuilder()
        sb.appendLine("Card Number,Name,Version,Set,Quantity,Manually Edited")
        cards.forEach { c ->
            sb.appendLine("${c.cardNumber},\"${c.cardName}\",${c.alternateType.label},\"${c.setName}\",${c.quantity},${c.manuallyEdited}")
        }
        return sb.toString()
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private suspend fun refreshSessionCount(sessionId: Long) {
        val total = cardDao.totalCardsInSession(sessionId) ?: 0
        sessionDao.updateCardCount(sessionId, total)
    }
}
