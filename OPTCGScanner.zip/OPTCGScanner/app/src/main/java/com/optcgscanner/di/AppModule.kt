package com.optcgscanner.di

import android.content.Context
import androidx.room.Room
import com.optcgscanner.data.db.*
import com.optcgscanner.network.TcgTrackingApi
import com.optcgscanner.network.TcgTrackingConstants
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ─── Database ────────────────────────────────────────────────────────────

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): OPTCGDatabase =
        Room.databaseBuilder(context, OPTCGDatabase::class.java, "optcg_database")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideCardCacheDao(db: OPTCGDatabase): CardCacheDao = db.cardCacheDao()
    @Provides fun provideSetCatalogueDao(db: OPTCGDatabase): SetCatalogueDao = db.setCatalogueDao()
    @Provides fun provideScanSessionDao(db: OPTCGDatabase): ScanSessionDao = db.scanSessionDao()
    @Provides fun provideScannedCardDao(db: OPTCGDatabase): ScannedCardDao = db.scannedCardDao()

    // ─── Network ─────────────────────────────────────────────────────────────

    @Provides
    @Singleton
    fun provideMoshi(): Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS) // Sets can be large JSON
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    @Provides
    @Singleton
    fun provideTcgTrackingApi(moshi: Moshi, okHttpClient: OkHttpClient): TcgTrackingApi =
        Retrofit.Builder()
            .baseUrl(TcgTrackingConstants.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(TcgTrackingApi::class.java)
}
