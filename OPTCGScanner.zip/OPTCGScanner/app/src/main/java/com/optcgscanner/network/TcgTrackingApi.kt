package com.optcgscanner.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Path

// ─── API Response Models ─────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class CategoriesResponse(
    val categories: List<ApiCategory>
)

@JsonClass(generateAdapter = true)
data class ApiCategory(
    val id: Int,
    val name: String,
    @Json(name = "product_count") val productCount: Int
)

@JsonClass(generateAdapter = true)
data class SetsResponse(
    val sets: List<ApiSet>
)

@JsonClass(generateAdapter = true)
data class ApiSet(
    val id: Int,
    val name: String,
    @Json(name = "abbreviation") val abbreviation: String?,
    @Json(name = "product_count") val productCount: Int?
)

@JsonClass(generateAdapter = true)
data class ProductsResponse(
    val products: List<ApiProduct>
)

@JsonClass(generateAdapter = true)
data class ApiProduct(
    val id: Int,
    val name: String,
    @Json(name = "clean_name") val cleanName: String,
    @Json(name = "set_name") val setName: String,
    @Json(name = "set_abbr") val setAbbr: String?,
    val number: String?,
    val rarity: String?,
    @Json(name = "image_url") val imageUrl: String?
)

// ─── Retrofit Service ────────────────────────────────────────────────────────

interface TcgTrackingApi {
    @GET("v1/categories")
    suspend fun getCategories(): CategoriesResponse

    @GET("v1/{catId}/sets")
    suspend fun getSets(@Path("catId") catId: Int): SetsResponse

    @GET("v1/{catId}/sets/{setId}")
    suspend fun getProducts(
        @Path("catId") catId: Int,
        @Path("setId") setId: Int
    ): ProductsResponse
}

// ─── Constants ────────────────────────────────────────────────────────────────

object TcgTrackingConstants {
    const val BASE_URL = "https://tcgtracking.com/tcgapi/"
    const val GAME_NAME_ONE_PIECE = "One Piece"
    // Set category ID fallback — discovered at runtime from /categories
    const val ONE_PIECE_CAT_ID_FALLBACK = 0
}
