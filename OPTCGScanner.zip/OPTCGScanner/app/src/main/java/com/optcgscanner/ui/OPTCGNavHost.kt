package com.optcgscanner.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.optcgscanner.ui.review.ReviewScreen
import com.optcgscanner.ui.scanner.ScannerScreen
import com.optcgscanner.ui.sessions.SessionsScreen

sealed class Screen(val route: String) {
    object Sessions : Screen("sessions")
    object Scanner : Screen("scanner")
    object Review : Screen("review/{sessionId}") {
        fun forSession(id: Long) = "review/$id"
    }
}

@Composable
fun OPTCGNavHost() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Sessions.route) {

        composable(Screen.Sessions.route) {
            SessionsScreen(
                onStartScan = { navController.navigate(Screen.Scanner.route) },
                onOpenSession = { sessionId ->
                    navController.navigate(Screen.Review.forSession(sessionId))
                }
            )
        }

        composable(Screen.Scanner.route) {
            ScannerScreen(
                sessionId = -1L,
                onDone = { sessionId ->
                    navController.navigate(Screen.Review.forSession(sessionId)) {
                        popUpTo(Screen.Scanner.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Review.route) { backStackEntry ->
            val sessionId = backStackEntry.arguments?.getString("sessionId")?.toLongOrNull() ?: -1L
            ReviewScreen(
                sessionId = sessionId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
