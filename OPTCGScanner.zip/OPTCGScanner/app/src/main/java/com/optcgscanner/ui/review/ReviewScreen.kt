package com.optcgscanner.ui.review

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.optcgscanner.data.model.AlternateType
import com.optcgscanner.data.model.CardCache
import com.optcgscanner.data.model.ScannedCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    sessionId: Long,
    onBack: () -> Unit,
    viewModel: ReviewViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.exportStatus) {
        if (uiState.exportStatus is ExportStatus.Done) {
            viewModel.shareCsvFile((uiState.exportStatus as ExportStatus.Done).filePath)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Review Scan", fontWeight = FontWeight.Bold)
                        Text(
                            "${uiState.totalUniqueCards} unique · ${uiState.totalCardCount} total",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::exportCsv) {
                        Icon(Icons.Default.Share, contentDescription = "Export CSV")
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.cards.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.SearchOff, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text("No cards scanned yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(uiState.cards, key = { it.id }) { card ->
                    ScannedCardRow(
                        card = card,
                        onOpenVersionPicker = { viewModel.openVersionPicker(card) },
                        onEdit = { viewModel.startEditing(card) },
                        onDelete = { viewModel.deleteCard(card) },
                        onQuantityChange = { viewModel.setQuantity(card, it) }
                    )
                }
            }
        }
    }

    // ── Version picker bottom sheet ──────────────────────────────────────────
    if (uiState.versionPickerCard != null) {
        VersionPickerSheet(
            card = uiState.versionPickerCard!!,
            availableVersions = uiState.availableVersions,
            onSelect = viewModel::selectVersion,
            onDismiss = viewModel::dismissVersionPicker
        )
    }

    // ── Card-correction search bottom sheet ──────────────────────────────────
    if (uiState.editingCard != null) {
        EditCardSheet(
            card = uiState.editingCard!!,
            searchQuery = uiState.searchQuery,
            searchResults = uiState.searchResults,
            onSearchQueryChanged = viewModel::onSearchQueryChanged,
            onReplaceWith = viewModel::replaceWithSearchResult,
            onDismiss = viewModel::cancelEditing
        )
    }
}

// ─── Scanned card row ────────────────────────────────────────────────────────

@Composable
private fun ScannedCardRow(
    card: ScannedCard,
    onOpenVersionPicker: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onQuantityChange: (Int) -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card image
                AsyncImage(
                    model = card.imageUrl,
                    contentDescription = card.cardName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .height(72.dp)
                        .width(52.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )

                // Name + badge + set info
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            card.cardName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (card.manuallyEdited) {
                            Icon(Icons.Default.Edit, null, modifier = Modifier.size(11.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Text(
                        card.cardNumber,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        card.setName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // Alternate version badge — tappable to open picker
                    AlternateTypeBadge(
                        type = card.alternateType,
                        onClick = onOpenVersionPicker
                    )
                }

                // Quantity stepper
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(36.dp)) {
                    IconButton(onClick = { onQuantityChange(card.quantity + 1) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    }
                    Text("×${card.quantity}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                    IconButton(
                        onClick = { if (card.quantity > 1) onQuantityChange(card.quantity - 1) else showDeleteDialog = true },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Remove, null, modifier = Modifier.size(16.dp))
                    }
                }

                // Action column
                Column {
                    IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.SwapHoriz, "Change card", modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { showDeleteDialog = true }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, "Delete", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Remove card?") },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                    Text("Remove")
                }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") } }
        )
    }
}

// ─── Alternate type badge ────────────────────────────────────────────────────

@Composable
fun AlternateTypeBadge(
    type: AlternateType,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val bgColor = parseHexColor(type.badgeColorHex)

    val chip = @Composable {
        Row(
            modifier = modifier
                .clip(RoundedCornerShape(4.dp))
                .background(bgColor.copy(alpha = 0.18f))
                .border(1.dp, bgColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            if (type != AlternateType.BASE) {
                Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(10.dp), tint = bgColor)
            }
            Text(type.label, fontSize = 10.sp, color = bgColor, fontWeight = FontWeight.SemiBold)
            if (onClick != null) {
                Icon(Icons.Default.ExpandMore, null, modifier = Modifier.size(10.dp), tint = bgColor)
            }
        }
    }

    if (onClick != null) {
        Box(modifier = Modifier.clickable { onClick() }) { chip() }
    } else {
        chip()
    }
}

private fun parseHexColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (e: Exception) {
        Color.Gray
    }
}

// ─── Version picker sheet ────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VersionPickerSheet(
    card: ScannedCard,
    availableVersions: List<CardCache>,
    onSelect: (CardCache) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AsyncImage(
                    model = card.imageUrl,
                    contentDescription = null,
                    modifier = Modifier.height(50.dp).width(36.dp).clip(RoundedCornerShape(4.dp))
                )
                Column {
                    Text(card.cardName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${card.cardNumber} · ${availableVersions.size} version${if (availableVersions.size != 1) "s" else ""} available",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            HorizontalDivider()

            if (availableVersions.isEmpty()) {
                Text("Only one version available for this card.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Select the version you have:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                // Scrollable horizontal image row for cards with many alternates
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(availableVersions) { version ->
                        VersionCard(
                            version = version,
                            isSelected = version.productId == card.productId,
                            onClick = { onSelect(version) }
                        )
                    }
                }

                // List view below for full detail
                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(availableVersions) { version ->
                        VersionListRow(
                            version = version,
                            isSelected = version.productId == card.productId,
                            onClick = { onSelect(version) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VersionCard(
    version: CardCache,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor by animateColorAsState(
        if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
        label = "border"
    )
    Column(
        modifier = Modifier.width(90.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box {
            AsyncImage(
                model = version.imageUrl,
                contentDescription = version.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .height(120.dp)
                    .width(86.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { onClick() }
            )
            if (isSelected) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(20.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        AlternateTypeBadge(type = version.alternateType)
    }
}

@Composable
private fun VersionListRow(
    version: CardCache,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        else Color.Transparent,
        label = "bg"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AlternateTypeBadge(type = version.alternateType, modifier = Modifier.width(110.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                version.name,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "Rarity: ${version.rarity}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (isSelected) {
            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
}

// ─── Card-correction search sheet ────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditCardSheet(
    card: ScannedCard,
    searchQuery: String,
    searchResults: List<CardCache>,
    onSearchQueryChanged: (String) -> Unit,
    onReplaceWith: (CardCache) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Replace Card", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Currently: ${card.cardName} (${card.cardNumber})",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChanged,
                label = { Text("Search by name or card number") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            LazyColumn(
                modifier = Modifier.heightIn(max = 300.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(searchResults) { result ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onReplaceWith(result) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AsyncImage(
                            model = result.imageUrl,
                            contentDescription = result.baseName,
                            modifier = Modifier.height(50.dp).width(36.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(result.baseName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            Text("${result.cardNumber} · ${result.rarity}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(result.setName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AlternateTypeBadge(type = result.alternateType)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                }
            }
        }
    }
}
