package com.optcgscanner.ui.review

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.optcgscanner.data.model.CardCache
import com.optcgscanner.data.model.ScannedCard
import com.optcgscanner.data.repository.CardRepository
import com.optcgscanner.data.repository.SessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class ReviewUiState(
    val sessionId: Long = -1L,
    val cards: List<ScannedCard> = emptyList(),
    val totalUniqueCards: Int = 0,
    val totalCardCount: Int = 0,

    // ── Card-correction sheet (change the card entirely) ──────────────────
    val editingCard: ScannedCard? = null,
    val searchQuery: String = "",
    val searchResults: List<CardCache> = emptyList(),

    // ── Version-picker sheet (change which alternate of the same card) ────
    val versionPickerCard: ScannedCard? = null,
    val availableVersions: List<CardCache> = emptyList(),

    val exportStatus: ExportStatus = ExportStatus.Idle
)

sealed class ExportStatus {
    object Idle : ExportStatus()
    object Exporting : ExportStatus()
    data class Done(val filePath: String) : ExportStatus()
    data class Error(val message: String) : ExportStatus()
}

@HiltViewModel
class ReviewViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    @ApplicationContext private val context: Context,
    private val sessionRepository: SessionRepository,
    private val cardRepository: CardRepository
) : ViewModel() {

    private val sessionId: Long = checkNotNull(savedStateHandle["sessionId"])

    private val _uiState = MutableStateFlow(ReviewUiState(sessionId = sessionId))
    val uiState: StateFlow<ReviewUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            sessionRepository.observeCardsForSession(sessionId).collect { cards ->
                _uiState.update {
                    it.copy(
                        cards = cards,
                        totalUniqueCards = cards.size,
                        totalCardCount = cards.sumOf { c -> c.quantity }
                    )
                }
            }
        }
    }

    // ─── Quantity & delete ────────────────────────────────────────────────────

    fun setQuantity(card: ScannedCard, quantity: Int) {
        viewModelScope.launch { sessionRepository.updateCardQuantity(card.id, quantity) }
    }

    fun deleteCard(card: ScannedCard) {
        viewModelScope.launch { sessionRepository.deleteCard(card) }
    }

    // ─── Version picker (change alternate for an already-matched card) ────────

    fun openVersionPicker(card: ScannedCard) {
        viewModelScope.launch {
            val versions = cardRepository.lookupAllVersions(card.cardNumber)
            _uiState.update {
                it.copy(versionPickerCard = card, availableVersions = versions)
            }
        }
    }

    fun selectVersion(version: CardCache) {
        val card = _uiState.value.versionPickerCard ?: return
        viewModelScope.launch {
            sessionRepository.replaceWithVersion(card, version)
            _uiState.update { it.copy(versionPickerCard = null, availableVersions = emptyList()) }
        }
    }

    fun dismissVersionPicker() =
        _uiState.update { it.copy(versionPickerCard = null, availableVersions = emptyList()) }

    // ─── Card-correction search (replace with a completely different card) ────

    fun startEditing(card: ScannedCard) =
        _uiState.update { it.copy(editingCard = card, searchQuery = "", searchResults = emptyList()) }

    fun cancelEditing() =
        _uiState.update { it.copy(editingCard = null, searchQuery = "", searchResults = emptyList()) }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        viewModelScope.launch {
            if (query.length >= 2) {
                val results = cardRepository.searchByName(query)
                _uiState.update { it.copy(searchResults = results) }
            } else {
                _uiState.update { it.copy(searchResults = emptyList()) }
            }
        }
    }

    fun replaceWithSearchResult(replacement: CardCache) {
        val editing = _uiState.value.editingCard ?: return
        viewModelScope.launch {
            sessionRepository.replaceWithVersion(editing, replacement)
            cancelEditing()
        }
    }

    // ─── CSV Export ───────────────────────────────────────────────────────────

    fun exportCsv() {
        viewModelScope.launch {
            _uiState.update { it.copy(exportStatus = ExportStatus.Exporting) }
            try {
                val csv = sessionRepository.buildCsv(_uiState.value.cards)
                val fileName = "optcg_scan_$sessionId.csv"
                val file = File(context.cacheDir, fileName)
                file.writeText(csv)
                _uiState.update { it.copy(exportStatus = ExportStatus.Done(file.absolutePath)) }
            } catch (e: Exception) {
                _uiState.update { it.copy(exportStatus = ExportStatus.Error(e.message ?: "Export failed")) }
            }
        }
    }

    fun shareCsvFile(path: String) {
        val file = File(path)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Export scan session").also {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        _uiState.update { it.copy(exportStatus = ExportStatus.Idle) }
    }

    fun clearExportStatus() = _uiState.update { it.copy(exportStatus = ExportStatus.Idle) }
}
