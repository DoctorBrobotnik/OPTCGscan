package com.optcgscanner.ui.scanner

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.getSystemService
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.optcgscanner.data.model.CardCache
import com.optcgscanner.data.model.ScannedCard
import com.optcgscanner.data.repository.CardRepository
import com.optcgscanner.data.repository.SessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ScanUiState(
    val sessionId: Long = -1L,
    val totalScanned: Int = 0,
    val lastMatchedCard: CardCache? = null,
    val lastScannedEntry: ScannedCard? = null,
    val isLookingUp: Boolean = false,
    val unknownCardNumber: String? = null,
    val dbReady: Boolean = false,
    val dbCardCount: Int = 0
)

@HiltViewModel
class ScannerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val cardRepository: CardRepository,
    private val sessionRepository: SessionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ScanUiState())
    val uiState: StateFlow<ScanUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val count = cardRepository.totalCachedCards()
            _uiState.update { it.copy(dbReady = count > 0, dbCardCount = count) }
        }
    }

    fun startSession() {
        viewModelScope.launch {
            val sessionId = sessionRepository.createSession()
            _uiState.update { it.copy(sessionId = sessionId, totalScanned = 0) }
        }
    }

    fun onCardNumberDetected(cardNumber: String) {
        val sessionId = _uiState.value.sessionId
        if (sessionId < 0 || _uiState.value.isLookingUp) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLookingUp = true, unknownCardNumber = null) }

            // Always match to the base/standard version at scan time.
            // User can change to an alternate in the review screen.
            val card = cardRepository.lookupBaseByCardNumber(cardNumber)

            if (card != null) {
                val scanned = sessionRepository.recordScan(
                    sessionId = sessionId,
                    card = card
                )
                _uiState.update {
                    it.copy(
                        lastMatchedCard = card,
                        lastScannedEntry = scanned,
                        totalScanned = it.totalScanned + 1,
                        isLookingUp = false
                    )
                }
                vibrate()
            } else {
                _uiState.update {
                    it.copy(unknownCardNumber = cardNumber, isLookingUp = false)
                }
            }
        }
    }

    private fun vibrate() {
        context.getSystemService<Vibrator>()?.vibrate(
            VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)
        )
    }
}
