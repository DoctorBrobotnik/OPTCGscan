package com.optcgscanner.ui.sessions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.optcgscanner.data.model.ScanSession
import com.optcgscanner.data.repository.CardRepository
import com.optcgscanner.data.repository.SessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SessionsUiState(
    val sessions: List<ScanSession> = emptyList(),
    val dbCardCount: Int = 0,
    val isSyncing: Boolean = false,
    val syncProgress: Pair<Int, Int>? = null, // current/total
    val syncError: String? = null,
    val isFirstLaunch: Boolean = false
)

@HiltViewModel
class SessionsViewModel @Inject constructor(
    private val sessionRepository: SessionRepository,
    private val cardRepository: CardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SessionsUiState())
    val uiState: StateFlow<SessionsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            sessionRepository.allSessions.collect { sessions ->
                _uiState.update { it.copy(sessions = sessions) }
            }
        }
        checkDatabaseAndSync()
    }

    private fun checkDatabaseAndSync() {
        viewModelScope.launch {
            val count = cardRepository.totalCachedCards()
            _uiState.update { it.copy(dbCardCount = count, isFirstLaunch = count == 0) }
            if (count == 0) {
                // First launch: sync everything
                triggerFullSync()
            } else {
                // Refresh sets list in background (no-op if recent)
                cardRepository.ensureSetsListFresh()
            }
        }
    }

    fun triggerFullSync() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, syncError = null) }
            cardRepository.syncAllSets(
                onProgress = { current, total ->
                    _uiState.update { it.copy(syncProgress = Pair(current, total)) }
                }
            ).onFailure { e ->
                _uiState.update { it.copy(syncError = e.message) }
            }
            val count = cardRepository.totalCachedCards()
            _uiState.update {
                it.copy(
                    isSyncing = false,
                    syncProgress = null,
                    dbCardCount = count,
                    isFirstLaunch = count == 0
                )
            }
        }
    }

    fun deleteSession(session: ScanSession) {
        viewModelScope.launch { sessionRepository.deleteSession(session) }
    }

    fun dismissSyncError() = _uiState.update { it.copy(syncError = null) }
}
