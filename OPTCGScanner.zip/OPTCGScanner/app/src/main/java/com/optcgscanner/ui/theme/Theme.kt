package com.optcgscanner.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// One Piece inspired: navy + gold
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFE8A020),          // Gold
    onPrimary = Color(0xFF1A1A1A),
    primaryContainer = Color(0xFF3D2A00),
    secondary = Color(0xFF5B8FD4),        // Ocean blue
    background = Color(0xFF0D0D1A),       // Deep navy
    surface = Color(0xFF1A1A2E),
    surfaceVariant = Color(0xFF252540),
    onSurface = Color(0xFFEEEEEE),
    onSurfaceVariant = Color(0xFFAAAAAA)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFB07800),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE0A0),
    secondary = Color(0xFF2A5FAA),
    background = Color(0xFFF5F5FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEEEEF6),
)

@Composable
fun OPTCGScannerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
