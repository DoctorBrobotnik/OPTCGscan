package com.optcgscanner.util

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * One Piece card number patterns:
 *  - Main sets:    OP01-001 … OP14-999
 *  - Starter decks: ST01-001 … ST19-999
 *  - Extra boosters: EB01-001 …
 *  - Promo:        P-001 …
 *
 *  Regex: one of the prefixes followed by optional digit(s), dash, then 3 digits.
 */
private val CARD_NUMBER_REGEX =
    Regex("""(OP\d{2}|ST\d{2}|EB\d{2}|P)-\d{3}""", RegexOption.IGNORE_CASE)

/**
 * Consecutive-frame debounce: a card number must be seen this many frames in a row
 * before we emit it as a confirmed match. Avoids false positives from partial reads.
 */
private const val CONFIRM_FRAMES = 3

/**
 * After a successful scan, ignore scans for this card for this many milliseconds.
 * Prevents the same card triggering twice while you're moving to the next.
 */
private const val LOCKOUT_MS = 1_500L

/**
 * Only process every Nth frame to save CPU/battery.
 */
private const val SAMPLE_EVERY_N_FRAMES = 4

class CardNumberAnalyzer : ImageAnalysis.Analyzer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val _detectedCardNumber = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val detectedCardNumber = _detectedCardNumber.asSharedFlow()

    // ─── State ───────────────────────────────────────────────────────────────

    private var frameCount = 0
    private var consecutiveCount = 0
    private var lastCandidate: String? = null
    private var lastConfirmedNumber: String? = null
    private var lastConfirmedTime: Long = 0L

    // ─── Analysis ────────────────────────────────────────────────────────────

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % SAMPLE_EVERY_N_FRAMES != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image ?: run { imageProxy.close(); return }
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                processText(visionText.text)
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun processText(rawText: String) {
        // Normalise — ML Kit sometimes returns lowercase or with spaces
        val cleaned = rawText.uppercase().replace(" ", "")
        val match = CARD_NUMBER_REGEX.find(cleaned)?.value ?: run {
            // No match this frame — reset consecutive count
            if (lastCandidate != null) {
                consecutiveCount = 0
                lastCandidate = null
            }
            return
        }

        if (match == lastCandidate) {
            consecutiveCount++
        } else {
            lastCandidate = match
            consecutiveCount = 1
        }

        if (consecutiveCount >= CONFIRM_FRAMES) {
            val now = System.currentTimeMillis()
            val inLockout = match == lastConfirmedNumber &&
                    now - lastConfirmedTime < LOCKOUT_MS
            if (!inLockout) {
                lastConfirmedNumber = match
                lastConfirmedTime = now
                consecutiveCount = 0
                _detectedCardNumber.tryEmit(match)
            }
        }
    }
}
